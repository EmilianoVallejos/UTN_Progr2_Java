/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package conversiondetipo;

import java.util.Scanner;

/**
 *
 * @author emili
 */
public class Conversiondetipo {

    /**
     * Manejar conversiones de tipo y división en Java.
a. Escribe un programa que divida dos números enteros 
* ingresados por el usuario.
b. Modifica el código para usar double en lugar de int 
* y compara los resultados.
* 
* /*La división de numeros enteros en JAVA, 
        da como resultado un entero (se debe cambiar el tipo int de variable 
        división a tipo double. Sin embargo, en la expresión "num1/num2" 
        (ambos de tipo entero) hace que el problema persista. 
        SOLUCIÓN: Debe cambiarse al menos una de dichas variables (num1 o num2) tipo int a double.
        Para ello, se puede hacer lo siguiente: 1- una de las variables (num1 o num2) 
        multiplicarla por *1.0 (x ejemplo: num1*1.0).
        2- una de las variables (num1 o num2), se puede hacer técnica 'casting',
        agregando entre paréntesis el tipo al que queremos cambiar (double) (ejemplo: (double)num1) */  
     
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        int num1, num2;
        double division;
       
        System.out.println("Ingrese el primer numero: ");
        num1 = Integer.parseInt(input.nextLine());
        
        System.out.println("Ingrese el segundo numero: ");
        num2 = Integer.parseInt(input.nextLine());
        
        division = (double) num1 / num2; 
        System.out.println("El resultado de la división entre primer numero y segundo es:"+ division);
        
        
        
        
        
        
    }
    
}

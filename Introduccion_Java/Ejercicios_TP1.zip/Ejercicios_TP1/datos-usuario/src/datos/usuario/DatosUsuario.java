/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package datos.usuario;

import java.util.Scanner;


public class DatosUsuario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
       
        String nombre;       
        System.out.println("Ingresa tu nombre:");
        nombre = input.nextLine();
        
        
        int edad;
        System.out.println("Ingresa tu edad: ");
        edad = Integer.parseInt(input.nextLine());
        
        
        

    }
    
}

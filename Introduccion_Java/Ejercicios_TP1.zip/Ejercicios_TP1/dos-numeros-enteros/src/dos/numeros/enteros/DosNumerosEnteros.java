/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dos.numeros.enteros;

import java.util.Scanner;

/**
 *
 * @author emili
 */
public class DosNumerosEnteros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num1, num2, resta, suma, multiplicacion;
        double division;
        System.out.print("Ingrese el primer numero: ");
        num1= Integer.parseInt(input.nextLine());
        
        System.out.print("Ingrese el segundo numero: ");
        num2 = Integer.parseInt(input.nextLine());
                
        suma = num1 + num2;
        resta = num1 - num2;
        multiplicacion = num1 * num2;
        division = num1 / num2 ;
        System.out.print("El resultado de la suma es: " + suma +". El resultado de la resta: " +resta + ". El resultado de la multiplicacion: " + multiplicacion + ". El resultado de la division: " + division);
        
                
        
        
        
    }
    
}

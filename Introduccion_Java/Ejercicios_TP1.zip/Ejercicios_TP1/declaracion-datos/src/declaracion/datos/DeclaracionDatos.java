/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package declaracion.datos;

/**
 *
 * @author emili
 */
public class DeclaracionDatos {

    /*a. String nombre
b. int edad
c. double altura
d. boolean estudiante
Imprime los valores en pantalla usando System.out.println().
     */
    public static void main(String[] args) {
       String nombre = "Emiliano Victor Vallejos";
       int edad = 38;
       double altura = 1.70;
       boolean estudiante = true;
        
       System.out.println(nombre);
       System.out.println(edad);
       System.out.println(altura);
       System.out.println(estudiante);
    }
    
}
